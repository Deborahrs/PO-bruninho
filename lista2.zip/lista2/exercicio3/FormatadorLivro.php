<?php

class FormatadorLivro {

    public static function formatarPreco($valor) {
        return "R$ " . number_format($valor, 2, ",", ".");
    }

    public static function tituloMaiusculo($titulo) {
        return strtoupper($titulo);
    }

    public static function calcularTempoLeitura($paginas) {
        $minutos = $paginas * 2;
        $horas = $minutos / 60;
        return round($horas, 1) . " horas";
    }
}

?>
