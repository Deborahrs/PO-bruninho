<?php

require_once "FormatadorLivro.php";

echo "Preco formatado: " . FormatadorLivro::formatarPreco(39.9) . "<br>";
echo "Titulo em maiusculo: " . FormatadorLivro::tituloMaiusculo("dom casmurro") . "<br>";
echo "Tempo de leitura de um livro de 256 paginas: " . FormatadorLivro::calcularTempoLeitura(256) . "<br>";

?>
