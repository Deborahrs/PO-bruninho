<?php

require_once "Livro.php";

$livro1 = new Livro("Dom Casmurro", "Machado de Assis");
$livro2 = new Livro("O Cortico", "Aluisio Azevedo");
$livro3 = new Livro("Vidas Secas", "Graciliano Ramos");

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

echo "Quantidade de livros criados: " . Livro::$quantidade . "<br>";

?>
