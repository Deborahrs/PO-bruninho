<?php

require_once "Livro.php";

$livro1 = new Livro("Dom Casmurro", "Machado de Assis", 40);
$livro2 = new Livro("O Cortico", "Aluisio Azevedo", 35);
$livro3 = new Livro("Vidas Secas", "Graciliano Ramos", 30);

$livro2->setStatus(Livro::STATUS_EMPRESTADO);
$livro3->setStatus(Livro::STATUS_RESERVADO);

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

echo "Devolvendo o livro " . $livro2->getTitulo() . "...<br><br>";
$livro2->setStatus(Livro::STATUS_DISPONIVEL);

$livro2->exibir();

?>
