<?php

class Livro {
    const FRETE = 10;
    const STATUS_DISPONIVEL = "disponivel";
    const STATUS_EMPRESTADO = "emprestado";
    const STATUS_RESERVADO = "reservado";

    public static $quantidade = 0;
    public static $valorTotal = 0;

    private $titulo;
    private $autor;
    private $paginas;
    private $preco;
    private $status;

    public function __construct($titulo, $autor, $preco) {
        $this->titulo = $titulo;
        $this->autor = $autor;
        $this->setPreco($preco);
        $this->status = self::STATUS_DISPONIVEL;
        self::$quantidade++;
        self::$valorTotal = self::$valorTotal + $this->preco;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getAutor() {
        return $this->autor;
    }

    public function setAutor($autor) {
        $this->autor = $autor;
    }

    public function getPaginas() {
        return $this->paginas;
    }

    public function setPaginas($paginas) {
        $this->paginas = $paginas;
    }

    public function getPreco() {
        return $this->preco;
    }

    public function setPreco($preco) {
        if ($preco < 0) {
            echo "Erro: o preco nao pode ser negativo!<br>";
        } else {
            $this->preco = $preco;
        }
    }

    public function aplicarDesconto($percentual) {
        $desconto = $this->preco * $percentual / 100;
        $this->preco = $this->preco - $desconto;
    }

    public static function criarPadrao() {
        return new self("Sem titulo", "Sem autor", 0);
    }

    public function precoComFrete() {
        return $this->preco + self::FRETE;
    }

    public function getStatus() {
        return $this->status;
    }

    public function setStatus($status) {
        $this->status = $status;
    }

    public function exibir() {
        echo "Titulo: " . $this->titulo . "<br>";
        echo "Autor: " . $this->autor . "<br>";
        echo "Paginas: " . $this->paginas . "<br>";
        echo "Preco: R$ " . $this->preco . "<br>";
        echo "Status: " . $this->status . "<br>";
        echo "<br>";
    }
}

?>
