<?php

require_once "Livro.php";
require_once "FormatadorLivro.php";

$livro1 = new Livro("Dom Casmurro", "Machado de Assis", 40);
$livro1->setPaginas(256);

$livro2 = new Livro("O Cortico", "Aluisio Azevedo", 35);
$livro2->setPaginas(304);

$livro3 = new Livro("Vidas Secas", "Graciliano Ramos", 30);
$livro3->setPaginas(176);

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

echo "Titulo: " . FormatadorLivro::tituloMaiusculo($livro1->getTitulo()) . "<br>";
echo "Preco com frete: " . FormatadorLivro::formatarPreco($livro1->precoComFrete()) . "<br>";
echo "Tempo de leitura: " . FormatadorLivro::calcularTempoLeitura($livro1->getPaginas()) . "<br><br>";

echo "Quantidade de livros criados: " . Livro::$quantidade . "<br>";

?>
