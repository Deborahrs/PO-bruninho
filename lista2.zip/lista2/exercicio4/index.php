<?php

require_once "Livro.php";

$livro1 = new Livro("Dom Casmurro", "Machado de Assis", 40);
$livro2 = Livro::criarPadrao();

$livro1->exibir();

echo "Livro criado com criarPadrao():<br>";
$livro2->exibir();

$livro2->setTitulo("Vidas Secas");
$livro2->setAutor("Graciliano Ramos");
$livro2->setPreco(30);

echo "Mesmo livro depois de usar os setters:<br>";
$livro2->exibir();

echo "Quantidade de livros criados: " . Livro::$quantidade . "<br>";

?>
