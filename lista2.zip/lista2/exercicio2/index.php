<?php

require_once "Livro.php";

$livro1 = new Livro("Dom Casmurro", "Machado de Assis", 40);
$livro2 = new Livro("O Cortico", "Aluisio Azevedo", 35);
$livro3 = new Livro("Vidas Secas", "Graciliano Ramos", 30);

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

echo "Quantidade de livros criados: " . Livro::$quantidade . "<br>";
echo "Valor total dos livros: R$ " . Livro::$valorTotal . "<br>";

?>
