## Lista 2

- [Exercicio 1](lista2/exercicio1)
- [Exercicio 2](lista2/exercicio2)
- [Exercicio 3](lista2/exercicio3)
- [Exercicio 4](lista2/exercicio4)
- [Exercicio 5](lista2/exercicio5)
- [Exercicio 6](lista2/exercicio6)
- [Exercicio 7](lista2/exercicio7)
- [Exercicio 8](lista2/exercicio8)
- [Exercicio 9](lista2/exercicio9)
