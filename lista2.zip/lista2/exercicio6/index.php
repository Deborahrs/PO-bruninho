<?php

require_once "Livro.php";

$livro1 = new Livro("Dom Casmurro", "Machado de Assis", 40);
$livro2 = new Livro("O Cortico", "Aluisio Azevedo", 35);

$livro1->exibir();
echo "Preco com frete: R$ " . $livro1->precoComFrete() . "<br><br>";

$livro2->exibir();
echo "Preco com frete: R$ " . $livro2->precoComFrete() . "<br><br>";

echo "Valor do frete: R$ " . Livro::FRETE . "<br>";

?>
