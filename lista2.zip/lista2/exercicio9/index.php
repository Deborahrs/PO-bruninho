<?php

require_once "Livro.php";

new Livro("Dom Casmurro", "Machado de Assis", 40);
new Livro("O Cortico", "Aluisio Azevedo", 35);
new Livro("Vidas Secas", "Graciliano Ramos", 30);

echo "<h3>Todos os livros cadastrados</h3>";
Livro::listarTodos();

echo "Total: " . Livro::$quantidade . " livros<br>";

?>
