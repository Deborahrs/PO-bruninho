<?php

// Diferenca entre self::$algo e $this->algo:
// $this->algo acessa um atributo do objeto, entao cada objeto tem o seu proprio valor.
// self::$algo acessa um atributo static, que pertence a classe e e o mesmo para todos os objetos.
// Por isso dentro de um metodo static nao existe $this, porque o metodo e chamado pela classe e nao por um objeto.

// Teste proposital, versao com erro:
//
// class Contador {
//     public static $total = 0;
//
//     public static function aumentar() {
//         $this->total++;
//     }
// }
//
// Contador::aumentar();
//
// Erro que apareceu no navegador:
// Fatal error: Uncaught Error: Using $this when not in object context

class Contador {
    public static $total = 0;

    public static function aumentar() {
        self::$total++;
    }
}

Contador::aumentar();
Contador::aumentar();
Contador::aumentar();

echo "Total: " . Contador::$total . "<br>";

?>
