<?php
/**
 * Exercício 4 — Loja virtual
 * Livro e Eletronico herdam de Produto.
 */

header('Content-Type: text/plain; charset=utf-8');

function moeda(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

class Produto
{
    protected string $nome;
    protected float $preco;
    protected string $codigo;

    public function __construct(string $nome, float $preco, string $codigo)
    {
        $this->nome   = $nome;
        $this->preco  = $preco;
        $this->codigo = $codigo;
    }

    public function getPreco(): float
    {
        return $this->preco;
    }

    public function exibirProduto(): void
    {
        echo "Código: {$this->codigo}" . PHP_EOL;
        echo "Nome:   {$this->nome}" . PHP_EOL;
        echo "Preço:  " . moeda($this->preco) . PHP_EOL;
    }

    public function aplicarDesconto(float $percentual): bool
    {
        // Só aceita percentual maior que 0 e no máximo 100
        if ($percentual <= 0 || $percentual > 100) {
            echo "Desconto de {$percentual}% RECUSADO: informe um percentual maior que 0 e até 100." . PHP_EOL;
            return false; // sai do método sem mexer no preço
        }

        $this->preco -= $this->preco * ($percentual / 100);
        echo "Desconto de {$percentual}% aplicado." . PHP_EOL;
        return true;
    }
}

class Livro extends Produto
{
    private string $autor;
    private string $isbn;

    public function __construct(string $nome, float $preco, string $codigo, string $autor, string $isbn)
    {
        parent::__construct($nome, $preco, $codigo);
        $this->autor = $autor;
        $this->isbn  = $isbn;
    }

    public function exibirProduto(): void
    {
        parent::exibirProduto();
        echo "Autor:  {$this->autor}" . PHP_EOL;
        echo "ISBN:   {$this->isbn}" . PHP_EOL;
    }
}

class Eletronico extends Produto
{
    private string $marca;
    private int $garantiaMeses;

    public function __construct(string $nome, float $preco, string $codigo, string $marca, int $garantiaMeses)
    {
        parent::__construct($nome, $preco, $codigo);
        $this->marca         = $marca;
        $this->garantiaMeses = $garantiaMeses;
    }

    public function exibirProduto(): void
    {
        parent::exibirProduto();
        echo "Marca:    {$this->marca}" . PHP_EOL;
        echo "Garantia: {$this->garantiaMeses} meses" . PHP_EOL;
    }
}

// ---------------------------------------------------------------
// Testes
// ---------------------------------------------------------------

$livro      = new Livro('Dom Casmurro', 100.00, 'LIV-001', 'Machado de Assis', '978-85-0000-001-1');
$eletronico = new Eletronico('Notebook', 2000.00, 'ELE-001', 'Lenovo', 12);

echo "########## CENÁRIO VÁLIDO ##########" . PHP_EOL . PHP_EOL;

echo "=== LIVRO ===" . PHP_EOL;
$livro->exibirProduto();
echo "Preço antes:  " . moeda($livro->getPreco()) . PHP_EOL;
$livro->aplicarDesconto(10);
echo "Preço depois: " . moeda($livro->getPreco()) . PHP_EOL;

echo PHP_EOL . "=== ELETRÔNICO ===" . PHP_EOL;
$eletronico->exibirProduto();
echo "Preço antes:  " . moeda($eletronico->getPreco()) . PHP_EOL;
$eletronico->aplicarDesconto(15);
echo "Preço depois: " . moeda($eletronico->getPreco()) . PHP_EOL;

echo PHP_EOL . "########## CENÁRIO INVÁLIDO ##########" . PHP_EOL . PHP_EOL;

echo "=== LIVRO: tentando desconto negativo ===" . PHP_EOL;
$precoAntes = $livro->getPreco();
echo "Preço antes:  " . moeda($precoAntes) . PHP_EOL;
$livro->aplicarDesconto(-10);
echo "Preço depois: " . moeda($livro->getPreco()) . PHP_EOL;

if ($livro->getPreco() === $precoAntes) {
    echo "OK: o preço não foi alterado." . PHP_EOL;
}
