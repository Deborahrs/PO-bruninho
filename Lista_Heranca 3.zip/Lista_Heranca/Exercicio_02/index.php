<?php
/**
 * Exercício 2 — Funcionários
 * Gerente e Desenvolvedor herdam de Funcionario.
 */

header('Content-Type: text/plain; charset=utf-8');

function moeda(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

class Funcionario
{
    protected string $nome;
    protected string $cpf;
    protected float $salario;

    public function __construct(string $nome, string $cpf, float $salario)
    {
        $this->nome    = $nome;
        $this->cpf     = $cpf;
        $this->salario = $salario;
    }

    public function exibirFuncionario(): void
    {
        echo "Nome:    {$this->nome}" . PHP_EOL;
        echo "CPF:     {$this->cpf}" . PHP_EOL;
        echo "Salário: " . moeda($this->salario) . PHP_EOL;
    }
}

class Gerente extends Funcionario
{
    private string $setor;

    public function __construct(string $nome, string $cpf, float $salario, string $setor)
    {
        parent::__construct($nome, $cpf, $salario);
        $this->setor = $setor;
    }

    public function realizarReuniao(): void
    {
        // $this->nome é protected em Funcionario, então a subclasse pode usar
        echo "{$this->nome} está conduzindo uma reunião com o setor de {$this->setor}." . PHP_EOL;
    }
}

class Desenvolvedor extends Funcionario
{
    private string $linguagem;

    public function __construct(string $nome, string $cpf, float $salario, string $linguagem)
    {
        parent::__construct($nome, $cpf, $salario);
        $this->linguagem = $linguagem;
    }

    public function programar(): void
    {
        echo "{$this->nome} está programando em {$this->linguagem}." . PHP_EOL;
    }
}

// ---------------------------------------------------------------
// Testes
// ---------------------------------------------------------------

$gerente = new Gerente('Mariana Costa', '123.456.789-00', 9500.00, 'Vendas');
$dev     = new Desenvolvedor('Lucas Pereira', '987.654.321-00', 6800.00, 'PHP');

echo "=== GERENTE ===" . PHP_EOL;
$gerente->exibirFuncionario();   // método herdado de Funcionario
$gerente->realizarReuniao();     // método específico de Gerente

echo PHP_EOL . "=== DESENVOLVEDOR ===" . PHP_EOL;
$dev->exibirFuncionario();       // método herdado de Funcionario
$dev->programar();               // método específico de Desenvolvedor

echo PHP_EOL . "=== TESTE: chamando programar() em um Gerente ===" . PHP_EOL;

/*
 * Explicação do resultado:
 * programar() foi declarado em Desenvolvedor, não em Funcionario.
 * Gerente e Desenvolvedor são "irmãos": os dois herdam de Funcionario,
 * mas um não herda do outro. A herança só passa da classe pai para a
 * classe filha, então Gerente recebe apenas o que existe em Funcionario
 * (exibirFuncionario) mais o que ele mesmo declara (realizarReuniao).
 *
 * Por isso o PHP lança um Error: "Call to undefined method Gerente::programar()".
 * Sem o try/catch, isso seria um Fatal error e o script pararia aqui.
 * O try/catch serve só para capturar o erro e mostrar a mensagem na tela.
 */
try {
    $gerente->programar();
} catch (Error $e) {
    echo "Erro capturado: " . $e->getMessage() . PHP_EOL;
    echo "Motivo: programar() pertence a Desenvolvedor, e Gerente não herda de Desenvolvedor." . PHP_EOL;
}
