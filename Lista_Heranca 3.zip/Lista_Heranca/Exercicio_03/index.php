<?php
/**
 * Exercício 3 — Sistema acadêmico
 * Aluno e Professor herdam de Pessoa.
 */

header('Content-Type: text/plain; charset=utf-8');

class Pessoa
{
    protected string $nome;
    protected int $idade;
    protected string $email;

    public function __construct(string $nome, int $idade, string $email)
    {
        $this->nome  = $nome;
        $this->idade = $idade;
        $this->email = $email;
    }

    public function apresentar(): void
    {
        echo "Olá, meu nome é {$this->nome}, tenho {$this->idade} anos. E-mail: {$this->email}" . PHP_EOL;
    }
}

class Aluno extends Pessoa
{
    private string $matricula;
    private string $curso;

    public function __construct(string $nome, int $idade, string $email, string $matricula, string $curso)
    {
        parent::__construct($nome, $idade, $email);
        $this->matricula = $matricula;
        $this->curso     = $curso;
    }

    public function estudar(): void
    {
        echo "{$this->nome} (matrícula {$this->matricula}) está estudando para o curso de {$this->curso}." . PHP_EOL;
    }
}

class Professor extends Pessoa
{
    private string $especialidade;
    private float $salario;

    public function __construct(string $nome, int $idade, string $email, string $especialidade, float $salario)
    {
        parent::__construct($nome, $idade, $email);
        $this->especialidade = $especialidade;
        $this->salario       = $salario;
    }

    public function ministrarAula(): void
    {
        echo "Prof. {$this->nome} está ministrando uma aula de {$this->especialidade}." . PHP_EOL;
    }
}

// ---------------------------------------------------------------
// Testes
// ---------------------------------------------------------------

$aluno1    = new Aluno('Beatriz Rocha', 19, 'beatriz@aluno.edu.br', '2024001', 'Sistemas de Informação');
$aluno2    = new Aluno('Pedro Alves', 22, 'pedro@aluno.edu.br', '2023045', 'Análise e Desenvolvimento de Sistemas');
$professor = new Professor('Ricardo Nunes', 45, 'ricardo@prof.edu.br', 'Programação Orientada a Objetos', 8200.00);

echo "=== ALUNO 1 ===" . PHP_EOL;
$aluno1->apresentar();
$aluno1->estudar();

echo PHP_EOL . "=== ALUNO 2 ===" . PHP_EOL;
$aluno2->apresentar();
$aluno2->estudar();

echo PHP_EOL . "=== PROFESSOR ===" . PHP_EOL;
$professor->apresentar();
$professor->ministrarAula();

/*
 * Por que apresentar() funciona nas subclasses?
 *
 * apresentar() foi declarado só em Pessoa. Como Aluno e Professor usam
 * "extends Pessoa", eles herdam todos os métodos public e protected da
 * classe pai. Quando chamamos $aluno1->apresentar(), o PHP procura o
 * método primeiro em Aluno; como não encontra, sobe para Pessoa e executa
 * o de lá.
 *
 * Dentro do método, $this aponta para o objeto que fez a chamada (o aluno
 * ou o professor). Por isso cada um se apresenta com o próprio nome, idade
 * e e-mail, que foram guardados pelo parent::__construct().
 */
