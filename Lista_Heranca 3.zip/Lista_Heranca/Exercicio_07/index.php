<?php
/**
 * Exercício 7 — Sistema de entregas
 * EntregaMoto e EntregaDrone herdam de Entrega.
 */

/*
 * HIERARQUIA  (# = protected, - = private, + = public)
 *
 *                     +-----------------------+
 *                     |        Entrega        |
 *                     +-----------------------+
 *                     | # codigo              |
 *                     | # destino             |
 *                     | # distancia           |
 *                     +-----------------------+
 *                     | + exibirDados()       |
 *                     +-----------------------+
 *                          ^             ^
 *                          |             |
 *         +----------------+             +------------------+
 *         |                                                 |
 * +------------------------+              +----------------------------+
 * |      EntregaMoto       |              |        EntregaDrone        |
 * +------------------------+              +----------------------------+
 * | - nomeEntregador       |              | + DISTANCIA_MAXIMA = 20 km |
 * | - placa                |              | - modeloDrone              |
 * +------------------------+              | - cargaMaximaKg            |
 * | + exibirDados()        |              +----------------------------+
 * | + realizarEntrega()    |              | + exibirDados()            |
 * +------------------------+              | + realizarEntrega()        |
 *                                         +----------------------------+
 *
 * Membros HERDADOS de Entrega (as duas subclasses recebem):
 *   atributos: codigo, destino, distancia
 *   método:    exibirDados()  (as subclasses reaproveitam com parent::exibirDados())
 *
 * Membros ESPECÍFICOS:
 *   EntregaMoto:  nomeEntregador, placa, realizarEntrega()
 *   EntregaDrone: modeloDrone, cargaMaximaKg, DISTANCIA_MAXIMA, realizarEntrega()
 */

header('Content-Type: text/plain; charset=utf-8');

class Entrega
{
    protected string $codigo;
    protected string $destino;
    protected float $distancia; // em km

    public function __construct(string $codigo, string $destino, float $distancia)
    {
        $this->codigo    = $codigo;
        $this->destino   = $destino;
        $this->distancia = $distancia;
    }

    public function exibirDados(): void
    {
        echo "Código:    {$this->codigo}" . PHP_EOL;
        echo "Destino:   {$this->destino}" . PHP_EOL;
        echo "Distância: {$this->distancia} km" . PHP_EOL;
    }
}

class EntregaMoto extends Entrega
{
    private string $nomeEntregador;
    private string $placa;

    public function __construct(string $codigo, string $destino, float $distancia, string $nomeEntregador, string $placa)
    {
        parent::__construct($codigo, $destino, $distancia);
        $this->nomeEntregador = $nomeEntregador;
        $this->placa          = $placa;
    }

    public function exibirDados(): void
    {
        parent::exibirDados();
        echo "Entregador: {$this->nomeEntregador}" . PHP_EOL;
        echo "Placa:      {$this->placa}" . PHP_EOL;
    }

    public function realizarEntrega(): bool
    {
        echo "Entrega {$this->codigo} saiu de moto com {$this->nomeEntregador} para {$this->destino}." . PHP_EOL;
        return true;
    }
}

class EntregaDrone extends Entrega
{
    public const DISTANCIA_MAXIMA = 20; // km

    private string $modeloDrone;
    private float $cargaMaximaKg;

    public function __construct(string $codigo, string $destino, float $distancia, string $modeloDrone, float $cargaMaximaKg)
    {
        parent::__construct($codigo, $destino, $distancia);
        $this->modeloDrone   = $modeloDrone;
        $this->cargaMaximaKg = $cargaMaximaKg;
    }

    public function exibirDados(): void
    {
        parent::exibirDados();
        echo "Drone:        {$this->modeloDrone}" . PHP_EOL;
        echo "Carga máxima: " . number_format($this->cargaMaximaKg, 1, ',', '.') . " kg" . PHP_EOL;
    }

    public function realizarEntrega(): bool
    {
        // Drone não pode fazer entregas acima de 20 km
        if ($this->distancia > self::DISTANCIA_MAXIMA) {
            echo "Entrega {$this->codigo} RECUSADA: {$this->distancia} km ultrapassa o limite de "
                . self::DISTANCIA_MAXIMA . " km para drones." . PHP_EOL;
            return false;
        }

        echo "Entrega {$this->codigo} realizada pelo drone {$this->modeloDrone} até {$this->destino} "
            . "({$this->distancia} km)." . PHP_EOL;
        return true;
    }
}

// ---------------------------------------------------------------
// Testes
// ---------------------------------------------------------------

$moto        = new EntregaMoto('M-001', 'Rua das Flores, 120 - Centro', 12, 'João Silva', 'ABC1D23');
$droneValido = new EntregaDrone('D-001', 'Av. Brasil, 450 - Jardim', 8, 'SkyCarrier X1', 2.5);
$droneLonge  = new EntregaDrone('D-002', 'Distrito Industrial, Lote 9', 25, 'SkyCarrier X1', 2.5);

echo "########## CENÁRIO VÁLIDO ##########" . PHP_EOL . PHP_EOL;

echo "=== ENTREGA POR MOTO ===" . PHP_EOL;
$moto->exibirDados();
$moto->realizarEntrega();

echo PHP_EOL . "=== ENTREGA POR DRONE (8 km) ===" . PHP_EOL;
$droneValido->exibirDados();
$droneValido->realizarEntrega();

echo PHP_EOL . "########## CENÁRIO INVÁLIDO ##########" . PHP_EOL . PHP_EOL;

echo "=== ENTREGA POR DRONE (25 km) ===" . PHP_EOL;
$droneLonge->exibirDados();
$droneLonge->realizarEntrega();
