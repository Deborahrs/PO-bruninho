<?php
/**
 * Exercício 6 — Três níveis de classes
 *
 *   Pessoa
 *     └── Funcionario
 *           ├── Programador
 *           └── Designer
 */

header('Content-Type: text/plain; charset=utf-8');

function moeda(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

// Nível 1
class Pessoa
{
    protected string $nome;
    protected string $email;

    public function __construct(string $nome, string $email)
    {
        $this->nome  = $nome;
        $this->email = $email;
    }

    public function apresentar(): void
    {
        echo "Olá, eu sou {$this->nome} ({$this->email})." . PHP_EOL;
    }
}

// Nível 2: Funcionario herda de Pessoa
class Funcionario extends Pessoa
{
    protected float $salario;
    protected string $matricula;

    public function __construct(string $nome, string $email, float $salario, string $matricula)
    {
        parent::__construct($nome, $email);
        $this->salario   = $salario;
        $this->matricula = $matricula;
    }

    public function trabalhar(): void
    {
        echo "{$this->nome} (matrícula {$this->matricula}) está trabalhando. Salário: "
            . moeda($this->salario) . PHP_EOL;
    }
}

// Nível 3: Programador herda de Funcionario (e, por tabela, de Pessoa)
class Programador extends Funcionario
{
    private string $linguagemPrincipal;

    public function __construct(string $nome, string $email, float $salario, string $matricula, string $linguagemPrincipal)
    {
        // Chama o construtor de Funcionario, que por sua vez chama o de Pessoa
        parent::__construct($nome, $email, $salario, $matricula);
        $this->linguagemPrincipal = $linguagemPrincipal;
    }

    public function programar(): void
    {
        echo "{$this->nome} está programando em {$this->linguagemPrincipal}." . PHP_EOL;
    }
}

// Nível 3: Designer herda de Funcionario
class Designer extends Funcionario
{
    private string $ferramentaPrincipal;

    public function __construct(string $nome, string $email, float $salario, string $matricula, string $ferramentaPrincipal)
    {
        parent::__construct($nome, $email, $salario, $matricula);
        $this->ferramentaPrincipal = $ferramentaPrincipal;
    }

    public function criarLayout(): void
    {
        echo "{$this->nome} está criando um layout no {$this->ferramentaPrincipal}." . PHP_EOL;
    }
}

// ---------------------------------------------------------------
// Testes
// ---------------------------------------------------------------

$programador = new Programador('Carla Mendes', 'carla@empresa.com', 7500.00, 'F-1023', 'PHP');

echo "=== PROGRAMADOR ===" . PHP_EOL;
$programador->apresentar(); // declarado em Pessoa       (herdado de 2 níveis acima)
$programador->trabalhar();  // declarado em Funcionario  (herdado da classe pai)
$programador->programar();  // declarado em Programador  (método da própria classe)

$designer = new Designer('Diego Ramos', 'diego@empresa.com', 6200.00, 'F-2045', 'Figma');

echo PHP_EOL . "=== DESIGNER ===" . PHP_EOL;
$designer->apresentar();    // declarado em Pessoa
$designer->trabalhar();     // declarado em Funcionario
$designer->criarLayout();   // declarado em Designer

/*
 * Onde cada método foi declarado:
 *
 *   Método          | Classe onde foi declarado
 *   ----------------|--------------------------
 *   apresentar()    | Pessoa
 *   trabalhar()     | Funcionario
 *   programar()     | Programador
 *   criarLayout()   | Designer
 *
 * O Programador consegue chamar os três primeiros porque a herança é
 * transitiva: Programador herda de Funcionario, que herda de Pessoa.
 * Já criarLayout() não está disponível para o Programador, porque foi
 * declarado em Designer, que é uma classe "irmã".
 */
