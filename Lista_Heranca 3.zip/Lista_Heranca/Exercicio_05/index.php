<?php
/**
 * Exercício 5 — Contas bancárias
 * ContaCorrente e ContaPoupanca herdam de ContaBancaria.
 */

header('Content-Type: text/plain; charset=utf-8');

function moeda(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

class ContaBancaria
{
    protected string $titular;
    protected float $saldo;

    public function __construct(string $titular, float $saldoInicial)
    {
        $this->titular = $titular;
        $this->saldo   = $saldoInicial;
    }

    public function depositar(float $valor): bool
    {
        if ($valor <= 0) {
            echo "Depósito RECUSADO: o valor deve ser maior que zero." . PHP_EOL;
            return false;
        }

        $this->saldo += $valor;
        echo "Depósito de " . moeda($valor) . " realizado." . PHP_EOL;
        return true;
    }

    // Operação básica: só deixa sacar até o saldo disponível
    public function sacar(float $valor): bool
    {
        if ($valor <= 0) {
            echo "Saque RECUSADO: o valor deve ser maior que zero." . PHP_EOL;
            return false;
        }

        if ($valor > $this->saldo) {
            echo "Saque de " . moeda($valor) . " RECUSADO: saldo insuficiente (disponível: "
                . moeda($this->saldo) . ")." . PHP_EOL;
            return false; // o saldo não é alterado
        }

        $this->saldo -= $valor;
        echo "Saque de " . moeda($valor) . " realizado." . PHP_EOL;
        return true;
    }

    public function consultarSaldo(): float
    {
        return $this->saldo;
    }
}

class ContaCorrente extends ContaBancaria
{
    private float $limite;

    public function __construct(string $titular, float $saldoInicial, float $limite)
    {
        parent::__construct($titular, $saldoInicial);
        $this->limite = $limite;
    }

    // Saque que pode passar do saldo, usando o limite (cheque especial)
    public function usarLimite(float $valor): bool
    {
        $disponivel = $this->saldo + $this->limite;

        if ($valor <= 0 || $valor > $disponivel) {
            echo "Saque com limite RECUSADO: disponível com limite é " . moeda($disponivel) . "." . PHP_EOL;
            return false;
        }

        $this->saldo -= $valor;
        echo "Saque de " . moeda($valor) . " realizado usando o limite." . PHP_EOL;
        return true;
    }
}

class ContaPoupanca extends ContaBancaria
{
    private float $taxaRendimento; // em % (ex.: 0.5 = 0,5%)

    public function __construct(string $titular, float $saldoInicial, float $taxaRendimento)
    {
        parent::__construct($titular, $saldoInicial);
        $this->taxaRendimento = $taxaRendimento;
    }

    public function aplicarRendimento(): void
    {
        $rendimento   = $this->saldo * ($this->taxaRendimento / 100);
        $this->saldo += $rendimento;

        echo "Rendimento de " . number_format($this->taxaRendimento, 1, ',', '.') . "% aplicado: + "
            . moeda($rendimento) . PHP_EOL;
    }
}

// ---------------------------------------------------------------
// Testes
// ---------------------------------------------------------------

$conta = new ContaCorrente('Ana Souza', 1000.00, 500.00);

echo "########## CENÁRIO VÁLIDO ##########" . PHP_EOL . PHP_EOL;

echo "Saldo inicial: " . moeda($conta->consultarSaldo()) . PHP_EOL;
$conta->depositar(500.00);
$conta->sacar(200.00);
echo "Saldo atual:   " . moeda($conta->consultarSaldo()) . PHP_EOL;

echo PHP_EOL . "########## CENÁRIO INVÁLIDO ##########" . PHP_EOL . PHP_EOL;

$saldoAntes = $conta->consultarSaldo();
echo "Saldo antes da tentativa: " . moeda($saldoAntes) . PHP_EOL;
$conta->sacar(2000.00);
echo "Saldo depois da tentativa: " . moeda($conta->consultarSaldo()) . PHP_EOL;

if ($conta->consultarSaldo() === $saldoAntes) {
    echo "Comprovado: o saque foi recusado e o saldo permaneceu em "
        . moeda($conta->consultarSaldo()) . "." . PHP_EOL;
}

echo PHP_EOL . "########## MÉTODOS ESPECÍFICOS ##########" . PHP_EOL . PHP_EOL;

echo "=== ContaCorrente: usarLimite() ===" . PHP_EOL;
$contaLimite = new ContaCorrente('Carlos Dias', 300.00, 500.00);
echo "Saldo: " . moeda($contaLimite->consultarSaldo()) . " | Limite: R$ 500,00" . PHP_EOL;
$contaLimite->sacar(600.00);       // operação básica: recusa, passa do saldo
$contaLimite->usarLimite(600.00);  // com limite: aceita (300 + 500 = 800 disponíveis)
echo "Saldo atual: " . moeda($contaLimite->consultarSaldo()) . PHP_EOL;

echo PHP_EOL . "=== ContaPoupanca: aplicarRendimento() ===" . PHP_EOL;
$poupanca = new ContaPoupanca('Bruno Lima', 1000.00, 0.5);
echo "Saldo antes:  " . moeda($poupanca->consultarSaldo()) . PHP_EOL;
$poupanca->aplicarRendimento();
echo "Saldo depois: " . moeda($poupanca->consultarSaldo()) . PHP_EOL;
