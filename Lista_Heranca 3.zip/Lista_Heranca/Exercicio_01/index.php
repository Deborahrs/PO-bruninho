<?php
/**
 * Exercício 1 — Veículos
 * Carro e Moto herdam de Veiculo.
 */

header('Content-Type: text/plain; charset=utf-8');

class Veiculo
{
    protected string $marca;
    protected string $modelo;
    protected int $ano;

    public function __construct(string $marca, string $modelo, int $ano)
    {
        $this->marca  = $marca;
        $this->modelo = $modelo;
        $this->ano    = $ano;
    }

    public function exibirDados(): void
    {
        echo "Marca:  {$this->marca}" . PHP_EOL;
        echo "Modelo: {$this->modelo}" . PHP_EOL;
        echo "Ano:    {$this->ano}" . PHP_EOL;
    }
}

/*
 * Carro
 *   Atributos HERDADOS de Veiculo: marca, modelo, ano
 *   Atributo ESPECÍFICO de Carro:  quantidadePortas
 */
class Carro extends Veiculo
{
    private int $quantidadePortas;

    public function __construct(string $marca, string $modelo, int $ano, int $quantidadePortas)
    {
        // Repassa os dados comuns para o construtor da classe pai (Veiculo)
        parent::__construct($marca, $modelo, $ano);
        $this->quantidadePortas = $quantidadePortas;
    }

    // Reaproveita o exibirDados() de Veiculo e acrescenta o dado específico
    public function exibirDados(): void
    {
        parent::exibirDados();
        echo "Portas: {$this->quantidadePortas}" . PHP_EOL;
    }
}

/*
 * Moto
 *   Atributos HERDADOS de Veiculo: marca, modelo, ano
 *   Atributo ESPECÍFICO de Moto:   cilindradas
 */
class Moto extends Veiculo
{
    private int $cilindradas;

    public function __construct(string $marca, string $modelo, int $ano, int $cilindradas)
    {
        parent::__construct($marca, $modelo, $ano);
        $this->cilindradas = $cilindradas;
    }

    public function exibirDados(): void
    {
        parent::exibirDados();
        echo "Cilindradas: {$this->cilindradas} cc" . PHP_EOL;
    }
}

// ---------------------------------------------------------------
// Testes
// ---------------------------------------------------------------

$carro = new Carro('Volkswagen', 'Gol', 2020, 4);
$moto  = new Moto('Honda', 'CG 160', 2023, 160);

echo "=== CARRO ===" . PHP_EOL;
$carro->exibirDados();

echo PHP_EOL . "=== MOTO ===" . PHP_EOL;
$moto->exibirDados();
