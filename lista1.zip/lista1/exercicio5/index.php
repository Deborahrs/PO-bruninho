<?php

require_once "Livro.php";

$livro1 = new Livro();
$livro1->definirDados("Dom Casmurro", "Machado de Assis", 256, 40);

$livro2 = new Livro();
$livro2->definirDados("O Cortico", "Aluisio Azevedo", 304, 35);

$livro3 = new Livro();
$livro3->definirDados("Vidas Secas", "Graciliano Ramos", 176, 30);

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

echo "Preco do livro " . $livro1->titulo . " antes do desconto: R$ " . $livro1->preco . "<br>";
$livro1->aplicarDesconto(10);
echo "Preco do livro " . $livro1->titulo . " depois de 10% de desconto: R$ " . $livro1->preco . "<br>";

?>
