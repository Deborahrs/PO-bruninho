<?php

class Livro {
    public $titulo;
    public $autor;
    public $paginas;
    public $preco;

    public function definirDados($titulo, $autor, $paginas, $preco) {
        $this->titulo = $titulo;
        $this->autor = $autor;
        $this->paginas = $paginas;
        $this->preco = $preco;
    }

    public function aplicarDesconto($percentual) {
        $desconto = $this->preco * $percentual / 100;
        $this->preco = $this->preco - $desconto;
    }

    public function exibir() {
        echo "Titulo: " . $this->titulo . "<br>";
        echo "Autor: " . $this->autor . "<br>";
        echo "Paginas: " . $this->paginas . "<br>";
        echo "Preco: R$ " . $this->preco . "<br>";
        echo "<br>";
    }
}

?>
