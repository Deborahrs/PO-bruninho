<?php

require_once "Livro.php";

$livro1 = new Livro("Dom Casmurro", "Machado de Assis");
$livro1->setPaginas(256);
$livro1->setPreco(40);

$livro2 = new Livro("Livro Sem Autor");
$livro2->setPaginas(100);
$livro2->setPreco(15);

echo "Livro criado com os dois parametros:<br>";
$livro1->exibir();

echo "Livro criado so com o titulo:<br>";
$livro2->exibir();

?>
