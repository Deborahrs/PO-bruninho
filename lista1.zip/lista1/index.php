<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lista 1 - POO em PHP</title>
</head>
<body>
<h1>Lista de Exercicios 1 - POO em PHP</h1>
<ul>
<li><a href="exercicio1/">Exercicio 1</a></li>
<li><a href="exercicio2/">Exercicio 2</a></li>
<li><a href="exercicio3/">Exercicio 3</a></li>
<li><a href="exercicio4/">Exercicio 4</a></li>
<li><a href="exercicio5/">Exercicio 5</a></li>
<li><a href="exercicio6/">Exercicio 6</a></li>
<li><a href="exercicio7/">Exercicio 7</a></li>
<li><a href="exercicio8/">Exercicio 8</a></li>
<li><a href="exercicio9/">Exercicio 9</a></li>
<li><a href="exercicio10/">Exercicio 10</a></li>
<li><a href="exercicio11/">Exercicio 11</a></li>
</ul>
</body>
</html>
