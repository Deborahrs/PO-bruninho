<?php

class Livro {
    public $titulo;
    public $autor;
    public $paginas;

    public function exibir() {
        echo "Titulo: " . $this->titulo . "<br>";
        echo "Autor: " . $this->autor . "<br>";
        echo "Paginas: " . $this->paginas . "<br>";
        echo "<br>";
    }
}

$livro1 = new Livro();
$livro1->titulo = "Dom Casmurro";
$livro1->autor = "Machado de Assis";
$livro1->paginas = 256;

$livro1->exibir();

?>
