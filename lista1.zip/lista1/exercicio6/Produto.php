<?php

class Produto {
    public $nome;
    public $preco;

    public function definirDados($nome, $preco) {
        $this->nome = $nome;
        $this->preco = $preco;
    }

    public function exibir() {
        echo "Produto: " . $this->nome . " - R$ " . $this->preco . "<br>";
    }
}

?>
