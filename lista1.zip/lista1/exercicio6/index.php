<?php

require_once "Produto.php";
require_once "Pedido.php";

$produto1 = new Produto();
$produto1->definirDados("Caderno", 20);

$produto2 = new Produto();
$produto2->definirDados("Caneta", 3.5);

$produto3 = new Produto();
$produto3->definirDados("Mochila", 120);

$pedido1 = new Pedido();
$pedido1->definirDados(1, "Joao");
$pedido1->adicionarProduto($produto1);
$pedido1->adicionarProduto($produto2);

$pedido2 = new Pedido();
$pedido2->definirDados(2, "Maria");
$pedido2->adicionarProduto($produto3);
$pedido2->adicionarProduto($produto2);

$pedido1->exibir();
$pedido2->exibir();

?>
