<?php

class Pedido {
    public $numero;
    public $cliente;
    public $produtos = array();

    public function definirDados($numero, $cliente) {
        $this->numero = $numero;
        $this->cliente = $cliente;
    }

    public function adicionarProduto($produto) {
        $this->produtos[] = $produto;
    }

    public function calcularTotal() {
        $total = 0;
        foreach ($this->produtos as $p) {
            $total = $total + $p->preco;
        }
        return $total;
    }

    public function exibir() {
        echo "Pedido numero: " . $this->numero . "<br>";
        echo "Cliente: " . $this->cliente . "<br>";
        echo "Produtos:<br>";
        foreach ($this->produtos as $p) {
            $p->exibir();
        }
        echo "Total: R$ " . $this->calcularTotal() . "<br>";
        echo "<br>";
    }
}

?>
