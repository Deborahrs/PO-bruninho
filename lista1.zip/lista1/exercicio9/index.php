<?php

require_once "Livro.php";

$livro1 = new Livro("Dom Casmurro");
$livro1->setAutor("Machado de Assis");
$livro1->setPaginas(256);
$livro1->setPreco(40);

$livro2 = new Livro("O Cortico");
$livro2->setAutor("Aluisio Azevedo");
$livro2->setPaginas(304);
$livro2->setPreco(35);

$livro3 = new Livro("Vidas Secas");
$livro3->setAutor("Graciliano Ramos");
$livro3->setPaginas(176);
$livro3->setPreco(30);

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

echo "Titulo do primeiro livro: " . $livro1->getTitulo() . "<br>";

?>
