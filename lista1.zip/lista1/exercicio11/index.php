<?php

require_once "ContaBancaria.php";

$conta1 = new ContaBancaria("Ana", "1234-5", 500);
$conta2 = new ContaBancaria("Carlos", "5678-9", 1000);
$conta3 = new ContaBancaria("Beatriz", "9999-1");

echo "<h3>Contas criadas</h3>";
$conta1->exibir();
$conta2->exibir();
$conta3->exibir();

echo "<h3>Movimentacoes</h3>";
$conta1->depositar(200);
$conta2->sacar(300);
$conta3->sacar(50);
$conta3->depositar(100);
echo "<br>";

echo "<h3>Testando validacoes</h3>";
$conta1->setSaldo(-100);
$conta2->setTitular("C");
echo "<br>";

echo "<h3>Contas depois das movimentacoes</h3>";
$conta1->exibir();
$conta2->exibir();
$conta3->exibir();

echo "Saldo da conta de " . $conta1->getTitular() . ": R$ " . $conta1->getSaldo() . "<br>";

?>
