<?php

class ContaBancaria {
    private $titular;
    private $numero;
    private $saldo;

    public function __construct($titular, $numero, $saldo = 0) {
        $this->titular = $titular;
        $this->numero = $numero;
        $this->setSaldo($saldo);
    }

    public function getTitular() {
        return $this->titular;
    }

    public function setTitular($titular) {
        if (strlen($titular) < 2) {
            echo "Erro: o nome do titular precisa ter pelo menos 2 letras!<br>";
        } else {
            $this->titular = $titular;
        }
    }

    public function getNumero() {
        return $this->numero;
    }

    public function setNumero($numero) {
        $this->numero = $numero;
    }

    public function getSaldo() {
        return $this->saldo;
    }

    public function setSaldo($saldo) {
        if ($saldo < 0) {
            echo "Erro: o saldo nao pode ser negativo!<br>";
        } else {
            $this->saldo = $saldo;
        }
    }

    public function depositar($valor) {
        if ($valor <= 0) {
            echo "Erro: valor de deposito invalido!<br>";
        } else {
            $this->saldo = $this->saldo + $valor;
            echo "Deposito de R$ " . $valor . " feito na conta de " . $this->titular . "<br>";
        }
    }

    public function sacar($valor) {
        if ($valor > $this->saldo) {
            echo "Saldo insuficiente para sacar R$ " . $valor . " da conta de " . $this->titular . "<br>";
        } else {
            $this->saldo = $this->saldo - $valor;
            echo "Saque de R$ " . $valor . " feito na conta de " . $this->titular . "<br>";
        }
    }

    public function exibir() {
        echo "Titular: " . $this->titular . "<br>";
        echo "Numero da conta: " . $this->numero . "<br>";
        echo "Saldo: R$ " . $this->saldo . "<br>";
        echo "<br>";
    }
}

?>
