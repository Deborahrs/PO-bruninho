<?php

class Livro {
    public $titulo;
    public $autor;
    public $paginas;

    public function exibir() {
        echo "Titulo: " . $this->titulo . "<br>";
        echo "Autor: " . $this->autor . "<br>";
        echo "Paginas: " . $this->paginas . "<br>";
        echo "<br>";
    }
}

$livro1 = new Livro();
$livro1->titulo = "Dom Casmurro";
$livro1->autor = "Machado de Assis";
$livro1->paginas = 256;

$livro2 = new Livro();
$livro2->titulo = "O Cortico";
$livro2->autor = "Aluisio Azevedo";
$livro2->paginas = 304;

$livro3 = new Livro();
$livro3->titulo = "Vidas Secas";
$livro3->autor = "Graciliano Ramos";
$livro3->paginas = 176;

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

// Os 3 objetos nao se confundem porque cada new cria um objeto separado na memoria, com seus proprios valores de atributos, mesmo sendo da mesma classe.

?>
