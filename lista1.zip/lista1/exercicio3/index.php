<?php

class Livro {
    public $titulo;
    public $autor;
    public $paginas;

    public function definirDados($titulo, $autor, $paginas) {
        $this->titulo = $titulo;
        $this->autor = $autor;
        $this->paginas = $paginas;
    }

    public function exibir() {
        echo "Titulo: " . $this->titulo . "<br>";
        echo "Autor: " . $this->autor . "<br>";
        echo "Paginas: " . $this->paginas . "<br>";
        echo "<br>";
    }
}

$livro1 = new Livro();
$livro1->definirDados("Dom Casmurro", "Machado de Assis", 256);

$livro2 = new Livro();
$livro2->definirDados("O Cortico", "Aluisio Azevedo", 304);

$livro3 = new Livro();
$livro3->definirDados("Vidas Secas", "Graciliano Ramos", 176);

$livro1->exibir();
$livro2->exibir();
$livro3->exibir();

?>
