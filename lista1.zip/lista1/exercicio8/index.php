<?php

require_once "Livro.php";

$livro1 = new Livro();
$livro1->setTitulo("Dom Casmurro");
$livro1->setAutor("Machado de Assis");
$livro1->setPaginas(256);
$livro1->setPreco(40);

$livro2 = new Livro();
$livro2->setTitulo("O Cortico");
$livro2->setAutor("Aluisio Azevedo");
$livro2->setPaginas(304);
$livro2->setPreco(35);

$livro1->exibir();
$livro2->exibir();

echo "Tentando colocar preco -10 no livro " . $livro1->getTitulo() . ":<br>";
$livro1->setPreco(-10);
echo "Preco continua: R$ " . $livro1->getPreco() . "<br><br>";

echo "Colocando preco 50 no livro " . $livro1->getTitulo() . ":<br>";
$livro1->setPreco(50);
echo "Preco agora: R$ " . $livro1->getPreco() . "<br>";

?>
