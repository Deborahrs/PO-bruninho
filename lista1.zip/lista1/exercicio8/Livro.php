<?php

class Livro {
    private $titulo;
    private $autor;
    private $paginas;
    private $preco;

    public function getTitulo() {
        return $this->titulo;
    }

    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getAutor() {
        return $this->autor;
    }

    public function setAutor($autor) {
        $this->autor = $autor;
    }

    public function getPaginas() {
        return $this->paginas;
    }

    public function setPaginas($paginas) {
        $this->paginas = $paginas;
    }

    public function getPreco() {
        return $this->preco;
    }

    public function setPreco($preco) {
        if ($preco < 0) {
            echo "Erro: o preco nao pode ser negativo!<br>";
        } else {
            $this->preco = $preco;
        }
    }

    public function aplicarDesconto($percentual) {
        $desconto = $this->preco * $percentual / 100;
        $this->preco = $this->preco - $desconto;
    }

    public function exibir() {
        echo "Titulo: " . $this->titulo . "<br>";
        echo "Autor: " . $this->autor . "<br>";
        echo "Paginas: " . $this->paginas . "<br>";
        echo "Preco: R$ " . $this->preco . "<br>";
        echo "<br>";
    }
}

?>
